<div class="bg-white rounded-full flex items-center justify-center h-10 w-10" {{ $attributes->merge(['class' => '']) }}>
    <i class="fas fa-gavel text-blue-600 text-xl"></i>
</div>
